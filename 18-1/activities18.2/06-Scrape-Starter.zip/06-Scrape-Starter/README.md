# Scrape Starter

## Instructions

* Using the [unsolved file](Unsolved/server.js), the cheerio documentation, and what you've learned in class so far, scrape a website of your choice, save information from the page in a result array, and log it to the console.
